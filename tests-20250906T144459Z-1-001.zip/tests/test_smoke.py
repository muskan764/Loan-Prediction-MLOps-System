import os, joblib

def test_model_artifact_exists():
    assert os.path.exists('./models/loan_model.pkl')

def test_load_pipeline():
    art = joblib.load('./models/loan_model.pkl')
    assert 'pipeline' in art
