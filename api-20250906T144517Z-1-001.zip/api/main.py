from fastapi import FastAPI, Response, HTTPException
from pydantic import BaseModel
import pandas as pd
import joblib, time
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST

MODEL_PATH = "./models/loan_model.pkl"

artifact = joblib.load(MODEL_PATH)
pipe = artifact["pipeline"]
training_columns = artifact["training_columns"]

app = FastAPI(title="Loan Prediction API", version="1.0")

PREDICT_COUNTER = Counter("model_requests_total", "Total number of prediction requests")
PREDICT_ERRORS = Counter("model_request_errors_total", "Total number of failed prediction requests")
PREDICT_LATENCY = Histogram("model_prediction_latency_seconds", "Latency for predictions in seconds")
PREDICTION_SCORE = Gauge("model_last_prediction_score", "Last predicted positive class probability")

class LoanFeatures(BaseModel):
    # Flexible: accept arbitrary fields as dict
    __root__: dict

def to_frame(payload: dict) -> pd.DataFrame:
    df = pd.DataFrame([payload])
    # Ensure all training columns exist
    for col in training_columns:
        if col not in df.columns:
            df[col] = None
    return df[training_columns]

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/predict")
def predict(features: LoanFeatures):
    PREDICT_COUNTER.inc()
    start = time.time()
    try:
        data = features.__root__
        X = to_frame(data)
        y_prob = None
        if hasattr(pipe, "predict_proba"):
            y_prob = pipe.predict_proba(X)[:,1][0]
            PREDICTION_SCORE.set(float(y_prob))
        y_pred = pipe.predict(X)[0]
        elapsed = time.time() - start
        PREDICT_LATENCY.observe(elapsed)
        return {"prediction": int(y_pred), "proba": (float(y_prob) if y_prob is not None else None), "latency_seconds": elapsed}
    except Exception as e:
        PREDICT_ERRORS.inc()
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

# Append to inference log (parquet) for drift monitoring
import os
INFER_LOG_PATH = "./monitoring/inference_log.parquet"
def append_infer_log(record: dict):
    try:
        import pandas as pd
        df = pd.DataFrame([record])
        if os.path.exists(INFER_LOG_PATH):
            old = pd.read_parquet(INFER_LOG_PATH)
            all_df = pd.concat([old, df], ignore_index=True)
        else:
            all_df = df
        all_df.to_parquet(INFER_LOG_PATH, index=False)
    except Exception:
        pass

# Patch predict to log
from datetime import datetime

# Monkey-patch FastAPI route function defined earlier

# We redefine predict with logging (simple overwrite for this file context)

@app.post("/predict")
def predict_with_log(features: LoanFeatures):
    PREDICT_COUNTER.inc()
    start = time.time()
    try:
        data = features.__root__
        X = to_frame(data)
        y_prob = None
        if hasattr(pipe, "predict_proba"):
            y_prob = pipe.predict_proba(X)[:,1][0]
            PREDICTION_SCORE.set(float(y_prob))
        y_pred = pipe.predict(X)[0]
        elapsed = time.time() - start
        PREDICT_LATENCY.observe(elapsed)
        # log
        record = dict(data)
        record.update({"prediction": int(y_pred), "proba": (float(y_prob) if y_prob is not None else None), "ts": datetime.utcnow().isoformat()+"Z"})
        append_infer_log(record)
        return {"prediction": int(y_pred), "proba": (float(y_prob) if y_prob is not None else None), "latency_seconds": elapsed}
    except Exception as e:
        PREDICT_ERRORS.inc()
        raise HTTPException(status_code=400, detail=str(e))
