"""
Train model for loan prediction and export model artifact.

Usage:
  python src/train.py --data ./data/loan_approval_dataset.csv --target " loan_status" --out ./models/loan_model.pkl
"""
import argparse, json, datetime, joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import accuracy_score, roc_auc_score, f1_score

def infer_target(df, provided):
    if provided and provided in df.columns: return provided
    return df.columns[-1]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--target", default=" loan_status")
    ap.add_argument("--out", default="./models/loan_model.pkl")
    args = ap.parse_args()

    df = pd.read_csv(args.data)
    target = infer_target(df, args.target)
    y_raw = df[target]
    X = df.drop(columns=[target])

    # Infer binary target if needed
    if y_raw.dtype == "O" or str(y_raw.dtype).startswith("category"):
        unique_vals = sorted(y_raw.dropna().unique().tolist())
        pos_keywords = {"Y","Yes","Approved","A","1","True","T"}
        mapping = {v: (1 if str(v).strip() in pos_keywords else 0) for v in unique_vals}
        y = y_raw.map(mapping)
    else:
        if set(np.unique(y_raw.dropna())).issubset({0,1}):
            y = y_raw.astype(int)
        else:
            med = np.median(y_raw.dropna())
            y = (y_raw >= med).astype(int)

    cat_cols = [c for c in X.columns if X[c].dtype == "O" or str(X[c].dtype).startswith("category")]
    num_cols = [c for c in X.columns if c not in cat_cols]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y if y.nunique()==2 else None)

    numeric_transformer = Pipeline([("imputer", SimpleImputer(strategy="median"))])
    categorical_transformer = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                                        ("onehot", OneHotEncoder(handle_unknown="ignore"))])

    preprocessor = ColumnTransformer([("num", numeric_transformer, num_cols),
                                      ("cat", categorical_transformer, cat_cols)])

    clf = GradientBoostingClassifier(random_state=42)
    pipe = Pipeline([("preprocessor", preprocessor),
                     ("model", clf)])

    pipe.fit(X_train, y_train)
    y_pred = pipe.predict(X_test)

    metrics = {
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "f1": float(f1_score(y_test, y_pred)) if y.nunique()==2 else None,
    }

    try:
        if y.nunique()==2 and hasattr(pipe, "predict_proba"):
            y_prob = pipe.predict_proba(X_test)[:,1]
            metrics["roc_auc"] = float(roc_auc_score(y_test, y_prob))
    except Exception:
        pass

    artifact = {
        "pipeline": pipe,
        "target_col": target,
        "cat_cols": cat_cols,
        "num_cols": num_cols,
        "training_columns": list(X.columns),
        "created_at": datetime.datetime.utcnow().isoformat()+"Z",
        "metrics": metrics,
    }
    joblib.dump(artifact, args.out)
    print(json.dumps(metrics, indent=2))

if __name__ == "__main__":
    main()
