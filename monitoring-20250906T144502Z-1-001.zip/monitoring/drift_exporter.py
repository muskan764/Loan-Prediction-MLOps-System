"""
A tiny Prometheus exporter that computes a basic PSI drift metric
for numeric features using recent inference requests logged by the API.
Run: python monitoring/drift_exporter.py --train ./data/loan_approval_dataset.csv --log ./monitoring/inference_log.parquet --port 8002
"""
import argparse, os, time, json
import pandas as pd
import numpy as np
from http.server import BaseHTTPRequestHandler, HTTPServer

def psi(expected, actual, bins=10, eps=1e-6):
    # Compute Population Stability Index for 1-D arrays
    q = np.linspace(0, 1, bins+1)
    e_bins = np.quantile(expected, q)
    a_bins = e_bins  # same bin edges
    e_hist, _ = np.histogram(expected, bins=e_bins)
    a_hist, _ = np.histogram(actual, bins=a_bins)
    e_ratio = e_hist / (e_hist.sum() + eps)
    a_ratio = a_hist / (a_hist.sum() + eps)
    return float(np.sum((a_ratio - e_ratio) * np.log((a_ratio + eps) / (e_ratio + eps))))

def compute_metrics(train_df, recent_df):
    metrics = {}
    num_cols = [c for c in train_df.columns if pd.api.types.is_numeric_dtype(train_df[c])]
    for c in num_cols:
        tr = train_df[c].dropna().values
        rc = recent_df[c].dropna().values if c in recent_df.columns else np.array([])
        if len(tr) > 10 and len(rc) > 10:
            metrics[f"psi_{c}"] = psi(tr, rc)
    return metrics

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path != "/metrics":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")
            return
        m = exporter_metrics()
        out = ""
        for k,v in m.items():
            out += f"# HELP {k} Population Stability Index for {k}\n# TYPE {k} gauge\n{k} {v}\n"
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; version=0.0.4")
        self.end_headers()
        self.wfile.write(out.encode())

def exporter_metrics():
    # recompute each scrape
    train_df = pd.read_csv(ARGS.train)
    recent_df = pd.read_parquet(ARGS.log) if os.path.exists(ARGS.log) else pd.DataFrame()
    return compute_metrics(train_df, recent_df)

def main():
    httpd = HTTPServer(("0.0.0.0", ARGS.port), Handler)
    print(f"Serving drift metrics on :{ARGS.port}")
    httpd.serve_forever()

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", required=True)
    ap.add_argument("--log", default="./monitoring/inference_log.parquet")
    ap.add_argument("--port", type=int, default=8002)
    ARGS = ap.parse_args()
    main()
